"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, ImageIcon, Eye, Edit, Upload } from "lucide-react"

const banners = [
  {
    id: 1,
    title: "Summer Collection 2023",
    type: "hero_banner",
    image: "/placeholder.svg?height=200&width=400",
    ctaText: "Shop Now",
    ctaLink: "/collections/summer-2023",
    status: "active",
    startDate: "2023-06-01",
    endDate: "2023-08-31",
    position: "homepage_hero",
  },
  {
    id: 2,
    title: "Free Shipping Promotion",
    type: "promo_banner",
    image: "/placeholder.svg?height=100&width=400",
    ctaText: "Learn More",
    ctaLink: "/shipping",
    status: "active",
    startDate: "2023-06-15",
    endDate: "2023-12-31",
    position: "homepage_top",
  },
]

const pages = [
  {
    id: 1,
    title: "About Us",
    slug: "about",
    type: "page",
    status: "published",
    lastModified: "2023-06-10",
    author: "Admin",
  },
  {
    id: 2,
    title: "Privacy Policy",
    slug: "privacy",
    type: "page",
    status: "published",
    lastModified: "2023-05-20",
    author: "Admin",
  },
  {
    id: 3,
    title: "Terms & Conditions",
    slug: "terms",
    type: "page",
    status: "draft",
    lastModified: "2023-06-05",
    author: "Admin",
  },
]

export default function ContentPage() {
  const [activeTab, setActiveTab] = useState("banners")
  const [isAddBannerOpen, setIsAddBannerOpen] = useState(false)
  const [isAddPageOpen, setIsAddPageOpen] = useState(false)

  const getStatusColor = (status) => {
    switch (status) {
      case "active":
      case "published":
        return "bg-green-100 text-green-800"
      case "inactive":
      case "draft":
        return "bg-yellow-100 text-yellow-800"
      case "expired":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Content Management</h1>
        <div className="flex space-x-2">
          <Dialog open={isAddBannerOpen} onOpenChange={setIsAddBannerOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Banner
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Banner</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Banner Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Banner Title</Label>
                      <Input placeholder="e.g., Summer Collection 2023" />
                    </div>
                    <div className="space-y-2">
                      <Label>Banner Type</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="hero_banner">Hero Banner</SelectItem>
                          <SelectItem value="promo_banner">Promotion Banner</SelectItem>
                          <SelectItem value="category_banner">Category Banner</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Position</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select position" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="homepage_hero">Homepage Hero</SelectItem>
                        <SelectItem value="homepage_top">Homepage Top</SelectItem>
                        <SelectItem value="category_top">Category Top</SelectItem>
                        <SelectItem value="product_sidebar">Product Sidebar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Banner Image</h3>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <p className="mt-2 text-sm text-gray-600">Upload banner image</p>
                    <p className="text-xs text-gray-500">Recommended: 1920x600px for hero banners</p>
                    <Button variant="outline" className="mt-4">
                      Select Image
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Call to Action</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>CTA Text</Label>
                      <Input placeholder="e.g., Shop Now" />
                    </div>
                    <div className="space-y-2">
                      <Label>CTA Link</Label>
                      <Input placeholder="e.g., /collections/summer" />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Schedule</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Start Date</Label>
                      <Input type="datetime-local" />
                    </div>
                    <div className="space-y-2">
                      <Label>End Date</Label>
                      <Input type="datetime-local" />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddBannerOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsAddBannerOpen(false)}>Create Banner</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isAddPageOpen} onOpenChange={setIsAddPageOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="mr-2 h-4 w-4" />
                Add Page
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>Create New Page</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Page Title</Label>
                    <Input placeholder="e.g., About Us" />
                  </div>
                  <div className="space-y-2">
                    <Label>URL Slug</Label>
                    <Input placeholder="e.g., about-us" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Page Content</Label>
                  <Textarea placeholder="Write your page content here..." className="min-h-[300px]" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Meta Title</Label>
                    <Input placeholder="SEO title" />
                  </div>
                  <div className="space-y-2">
                    <Label>Meta Description</Label>
                    <Input placeholder="SEO description" />
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddPageOpen(false)}>
                    Save as Draft
                  </Button>
                  <Button onClick={() => setIsAddPageOpen(false)}>Publish</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Tab Navigation */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="banners">Banners</TabsTrigger>
          <TabsTrigger value="pages">Pages</TabsTrigger>
          <TabsTrigger value="media">Media Library</TabsTrigger>
        </TabsList>

        <TabsContent value="banners" className="space-y-6">
          {/* Summary Cards */}
          <div className="grid gap-6 md:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Banners</CardTitle>
                <ImageIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12</div>
                <p className="text-xs text-muted-foreground">All banners</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Banners</CardTitle>
                <ImageIcon className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8</div>
                <p className="text-xs text-muted-foreground">Currently showing</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Scheduled</CardTitle>
                <ImageIcon className="h-4 w-4 text-blue-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3</div>
                <p className="text-xs text-muted-foreground">Future banners</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Expired</CardTitle>
                <ImageIcon className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1</div>
                <p className="text-xs text-muted-foreground">Past banners</p>
              </CardContent>
            </Card>
          </div>

          {/* Banners Table */}
          <div className="rounded-md border bg-white">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Banner</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Position</TableHead>
                  <TableHead>Schedule</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {banners.map((banner) => (
                  <TableRow key={banner.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <Image
                          src={banner.image || "/placeholder.svg"}
                          alt={banner.title}
                          width={80}
                          height={40}
                          className="rounded object-cover"
                        />
                        <div>
                          <p className="font-medium">{banner.title}</p>
                          <p className="text-sm text-gray-500">
                            {banner.ctaText} → {banner.ctaLink}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="capitalize">{banner.type.replace("_", " ")}</TableCell>
                    <TableCell className="capitalize">{banner.position.replace("_", " ")}</TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <p>{banner.startDate}</p>
                        <p className="text-gray-500">to {banner.endDate}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(banner.status)}>{banner.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="pages" className="space-y-6">
          {/* Pages Table */}
          <div className="rounded-md border bg-white">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Page</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Modified</TableHead>
                  <TableHead>Author</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pages.map((page) => (
                  <TableRow key={page.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{page.title}</p>
                        <p className="text-sm text-gray-500">/{page.slug}</p>
                      </div>
                    </TableCell>
                    <TableCell className="capitalize">{page.type}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(page.status)}>{page.status}</Badge>
                    </TableCell>
                    <TableCell>{page.lastModified}</TableCell>
                    <TableCell>{page.author}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="media" className="space-y-6">
          <div className="text-center py-12">
            <ImageIcon className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-4 text-lg font-medium">Media Library</h3>
            <p className="mt-2 text-gray-600">Upload and manage your images, videos, and other media files</p>
            <Button className="mt-4">
              <Upload className="mr-2 h-4 w-4" />
              Upload Media
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
