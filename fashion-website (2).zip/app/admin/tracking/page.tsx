"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Phone, Navigation, Clock, Package, Truck, RefreshCw, MessageSquare, AlertTriangle } from "lucide-react"

const activeDeliveries = [
  {
    id: 1,
    orderId: "ORD-12345",
    shipper: {
      name: "Nguyễn Văn A",
      phone: "+84 123 456 789",
      avatar: "/placeholder.svg?height=40&width=40",
      vehicle: "Honda Wave",
    },
    customer: {
      name: "Trần Thị B",
      address: "123 Nguyễn Huệ, Quận 1, TP.HCM",
      phone: "+84 987 654 321",
    },
    currentLocation: {
      lat: 10.7769,
      lng: 106.7009,
      address: "456 Lê Lợi, Quận 1, TP.HCM",
    },
    destination: {
      lat: 10.7731,
      lng: 106.7031,
      address: "123 Nguyễn Huệ, Quận 1, TP.HCM",
    },
    status: "in_transit",
    estimatedArrival: "15:30",
    distance: "2.5 km",
    startTime: "14:00",
  },
  {
    id: 2,
    orderId: "ORD-12346",
    shipper: {
      name: "Lê Văn C",
      phone: "+84 555 123 456",
      avatar: "/placeholder.svg?height=40&width=40",
      vehicle: "Yamaha Sirius",
    },
    customer: {
      name: "Phạm Thị D",
      address: "789 Võ Văn Tần, Quận 3, TP.HCM",
      phone: "+84 111 222 333",
    },
    currentLocation: {
      lat: 10.7829,
      lng: 106.6934,
      address: "234 Pasteur, Quận 3, TP.HCM",
    },
    destination: {
      lat: 10.7891,
      lng: 106.6978,
      address: "789 Võ Văn Tần, Quận 3, TP.HCM",
    },
    status: "picking_up",
    estimatedArrival: "16:00",
    distance: "1.2 km",
    startTime: "15:15",
  },
]

export default function TrackingPage() {
  const [selectedDelivery, setSelectedDelivery] = useState(activeDeliveries[0])
  const [refreshing, setRefreshing] = useState(false)
  const [isContactShipperOpen, setIsContactShipperOpen] = useState(false)
  const [isReportIssueOpen, setIsReportIssueOpen] = useState(false)

  const handleRefresh = () => {
    setRefreshing(true)
    // Simulate API call
    setTimeout(() => {
      setRefreshing(false)
    }, 1000)
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "in_transit":
        return "bg-blue-100 text-blue-800"
      case "picking_up":
        return "bg-yellow-100 text-yellow-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      case "delayed":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case "in_transit":
        return <Truck className="h-4 w-4" />
      case "picking_up":
        return <Package className="h-4 w-4" />
      case "delivered":
        return <MapPin className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const handleContactShipper = (delivery) => {
    setSelectedDelivery(delivery)
    setIsContactShipperOpen(true)
  }

  const handleReportIssue = (delivery) => {
    setSelectedDelivery(delivery)
    setIsReportIssueOpen(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Real-time Tracking</h1>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={handleRefresh} disabled={refreshing}>
            <RefreshCw className={`mr-2 h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Select>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Deliveries</SelectItem>
              <SelectItem value="in_transit">In Transit</SelectItem>
              <SelectItem value="picking_up">Picking Up</SelectItem>
              <SelectItem value="delayed">Delayed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Deliveries</CardTitle>
            <Truck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">Currently on route</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Picking Up</CardTitle>
            <Package className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <p className="text-xs text-muted-foreground">At pickup location</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Delivered Today</CardTitle>
            <MapPin className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">28</div>
            <p className="text-xs text-muted-foreground">Completed deliveries</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Delivery Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">45m</div>
            <p className="text-xs text-muted-foreground">This week</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Delivery List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Active Deliveries</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-0">
                {activeDeliveries.map((delivery) => (
                  <div
                    key={delivery.id}
                    className={`p-4 border-b cursor-pointer hover:bg-gray-50 ${
                      selectedDelivery?.id === delivery.id ? "bg-blue-50 border-blue-200" : ""
                    }`}
                    onClick={() => setSelectedDelivery(delivery)}
                  >
                    <div className="flex items-start space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={delivery.shipper.avatar || "/placeholder.svg"} alt={delivery.shipper.name} />
                        <AvatarFallback>{delivery.shipper.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="font-medium text-sm">{delivery.orderId}</p>
                          <Badge className={getStatusColor(delivery.status)}>
                            <span className="flex items-center">
                              {getStatusIcon(delivery.status)}
                              <span className="ml-1">{delivery.status.replace("_", " ")}</span>
                            </span>
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{delivery.shipper.name}</p>
                        <p className="text-xs text-gray-500">{delivery.shipper.vehicle}</p>
                        <div className="flex items-center mt-2 text-xs text-gray-500">
                          <Clock className="h-3 w-3 mr-1" />
                          ETA: {delivery.estimatedArrival}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Map and Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Map Placeholder */}
          <Card>
            <CardHeader>
              <CardTitle>Live Map Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative h-96 bg-gray-100 rounded-lg overflow-hidden">
                {/* This would be replaced with an actual Google Map */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-500">Google Maps Integration</p>
                    <p className="text-sm text-gray-400">Real-time shipper location tracking</p>
                  </div>
                </div>

                {/* Map Controls */}
                <div className="absolute top-4 right-4 space-y-2">
                  <Button size="sm" variant="outline" className="bg-white">
                    <Navigation className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="bg-white">
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>

                {/* Location Info Overlay */}
                {selectedDelivery && (
                  <div className="absolute bottom-4 left-4 right-4 bg-white rounded-lg p-4 shadow-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{selectedDelivery.orderId}</p>
                        <p className="text-sm text-gray-600">{selectedDelivery.currentLocation.address}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">{selectedDelivery.distance} away</p>
                        <p className="text-xs text-gray-500">ETA: {selectedDelivery.estimatedArrival}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Delivery Details */}
          {selectedDelivery && (
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Shipper Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarImage
                        src={selectedDelivery.shipper.avatar || "/placeholder.svg"}
                        alt={selectedDelivery.shipper.name}
                      />
                      <AvatarFallback>{selectedDelivery.shipper.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium">{selectedDelivery.shipper.name}</p>
                      <p className="text-sm text-gray-600">{selectedDelivery.shipper.vehicle}</p>
                      <div className="flex items-center mt-1">
                        <Phone className="h-3 w-3 mr-1 text-gray-400" />
                        <span className="text-xs text-gray-500">{selectedDelivery.shipper.phone}</span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" onClick={() => handleContactShipper(selectedDelivery)}>
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Phone className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <MapPin className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Customer Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="font-medium">{selectedDelivery.customer.name}</p>
                      <div className="flex items-center mt-1">
                        <Phone className="h-3 w-3 mr-1 text-gray-400" />
                        <span className="text-xs text-gray-500">{selectedDelivery.customer.phone}</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Delivery Address:</p>
                      <div className="flex items-start mt-1">
                        <MapPin className="h-3 w-3 mr-1 text-gray-400 mt-0.5" />
                        <span className="text-xs text-gray-600">{selectedDelivery.customer.address}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t">
                      <span className="text-sm text-gray-600">Started:</span>
                      <span className="text-sm font-medium">{selectedDelivery.startTime}</span>
                    </div>
                    <div className="flex space-x-2 pt-2">
                      <Button size="sm" variant="outline" onClick={() => handleReportIssue(selectedDelivery)}>
                        <AlertTriangle className="mr-2 h-4 w-4" />
                        Report Issue
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>

      {/* Contact Shipper Modal */}
      <Dialog open={isContactShipperOpen} onOpenChange={setIsContactShipperOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Contact Shipper</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Shipper</Label>
              <Input value={selectedDelivery?.shipper.name} disabled />
            </div>
            <div className="space-y-2">
              <Label>Order ID</Label>
              <Input value={selectedDelivery?.orderId} disabled />
            </div>
            <div className="space-y-2">
              <Label>Message Type</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select message type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="location_update">Location Update Request</SelectItem>
                  <SelectItem value="delivery_instruction">Delivery Instructions</SelectItem>
                  <SelectItem value="customer_contact">Customer Contact Info</SelectItem>
                  <SelectItem value="urgent">Urgent Message</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Message</Label>
              <Textarea placeholder="Type your message to the shipper..." />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsContactShipperOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsContactShipperOpen(false)}>Send Message</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Report Issue Modal */}
      <Dialog open={isReportIssueOpen} onOpenChange={setIsReportIssueOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Report Delivery Issue</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Order ID</Label>
              <Input value={selectedDelivery?.orderId} disabled />
            </div>
            <div className="space-y-2">
              <Label>Issue Type</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select issue type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="delayed">Delivery Delayed</SelectItem>
                  <SelectItem value="wrong_address">Wrong Address</SelectItem>
                  <SelectItem value="customer_unavailable">Customer Unavailable</SelectItem>
                  <SelectItem value="vehicle_issue">Vehicle Issue</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Priority</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea placeholder="Describe the issue in detail..." />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsReportIssueOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsReportIssueOpen(false)}>Report Issue</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
