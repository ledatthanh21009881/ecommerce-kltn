"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, Plus, Package, AlertTriangle, TrendingUp, FileText } from "lucide-react"

const inventoryData = [
  {
    id: 1,
    product: "BLACK SIDE PLEAT WIDE LEG JEANS",
    sku: "BSP-WLJ-001",
    category: "Bottoms",
    stock: 25,
    reserved: 5,
    available: 20,
    reorderLevel: 10,
    supplier: "Textile Co.",
    lastRestocked: "2023-06-10",
    status: "in_stock",
  },
  {
    id: 2,
    product: "BLACK CUT-OUT LONG SLEEVE SHIRT",
    sku: "BCO-LSS-002",
    category: "Tops",
    stock: 8,
    reserved: 2,
    available: 6,
    reorderLevel: 15,
    supplier: "Fashion Ltd.",
    lastRestocked: "2023-06-05",
    status: "low_stock",
  },
  {
    id: 3,
    product: "SMUDGE STRAIGHT FIT JEANS",
    sku: "SSF-JNS-003",
    category: "Bottoms",
    stock: 0,
    reserved: 0,
    available: 0,
    reorderLevel: 12,
    supplier: "Denim Works",
    lastRestocked: "2023-05-20",
    status: "out_of_stock",
  },
]

const stockMovements = [
  {
    id: 1,
    type: "in",
    product: "BLACK SIDE PLEAT WIDE LEG JEANS",
    quantity: 50,
    date: "2023-06-10",
    reason: "Purchase Order #PO-001",
  },
  {
    id: 2,
    type: "out",
    product: "BLACK CUT-OUT LONG SLEEVE SHIRT",
    quantity: 3,
    date: "2023-06-12",
    reason: "Order #ORD-12345",
  },
  {
    id: 3,
    type: "adjustment",
    product: "SMUDGE STRAIGHT FIT JEANS",
    quantity: -2,
    date: "2023-06-11",
    reason: "Damaged items",
  },
]

export default function InventoryPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isStockInOpen, setIsStockInOpen] = useState(false)
  const [isStockOutOpen, setIsStockOutOpen] = useState(false)

  const getStatusColor = (status) => {
    switch (status) {
      case "in_stock":
        return "bg-green-100 text-green-800"
      case "low_stock":
        return "bg-yellow-100 text-yellow-800"
      case "out_of_stock":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getMovementColor = (type) => {
    switch (type) {
      case "in":
        return "text-green-600"
      case "out":
        return "text-red-600"
      case "adjustment":
        return "text-blue-600"
      default:
        return "text-gray-600"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Inventory Management</h1>
        <div className="flex space-x-2">
          <Dialog open={isStockInOpen} onOpenChange={setIsStockInOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Stock In
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Stock In - Add Inventory</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Product</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select product" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="product1">BLACK SIDE PLEAT WIDE LEG JEANS</SelectItem>
                        <SelectItem value="product2">BLACK CUT-OUT LONG SLEEVE SHIRT</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Supplier</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select supplier" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="supplier1">Textile Co.</SelectItem>
                        <SelectItem value="supplier2">Fashion Ltd.</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Quantity</Label>
                    <Input type="number" placeholder="0" />
                  </div>
                  <div className="space-y-2">
                    <Label>Unit Cost</Label>
                    <Input type="number" placeholder="0" />
                  </div>
                  <div className="space-y-2">
                    <Label>Total Cost</Label>
                    <Input type="number" placeholder="0" disabled />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Reference (PO Number)</Label>
                  <Input placeholder="PO-001" />
                </div>
                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea placeholder="Additional notes..." />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsStockInOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsStockInOpen(false)}>Add Stock</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isStockOutOpen} onOpenChange={setIsStockOutOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Package className="mr-2 h-4 w-4" />
                Stock Adjustment
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Stock Adjustment</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Product</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select product" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="product1">BLACK SIDE PLEAT WIDE LEG JEANS</SelectItem>
                      <SelectItem value="product2">BLACK CUT-OUT LONG SLEEVE SHIRT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Adjustment Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="increase">Increase</SelectItem>
                        <SelectItem value="decrease">Decrease</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Quantity</Label>
                    <Input type="number" placeholder="0" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Reason</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select reason" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="damaged">Damaged</SelectItem>
                      <SelectItem value="lost">Lost</SelectItem>
                      <SelectItem value="returned">Customer Return</SelectItem>
                      <SelectItem value="correction">Stock Correction</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea placeholder="Additional details..." />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsStockOutOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsStockOutOpen(false)}>Apply Adjustment</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">156</div>
            <p className="text-xs text-muted-foreground">+12 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Items</CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-muted-foreground">Requires attention</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Out of Stock</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">Immediate reorder needed</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Value</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2.4B Đ</div>
            <p className="text-xs text-muted-foreground">Current inventory value</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex items-center space-x-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search inventory..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="tops">Tops</SelectItem>
            <SelectItem value="bottoms">Bottoms</SelectItem>
          </SelectContent>
        </Select>
        <Select>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Stock Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="in_stock">In Stock</SelectItem>
            <SelectItem value="low_stock">Low Stock</SelectItem>
            <SelectItem value="out_of_stock">Out of Stock</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Inventory Table */}
      <div className="rounded-md border bg-white">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead>SKU</TableHead>
              <TableHead>Stock</TableHead>
              <TableHead>Reserved</TableHead>
              <TableHead>Available</TableHead>
              <TableHead>Reorder Level</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Last Restocked</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {inventoryData.map((item) => (
              <TableRow key={item.id}>
                <TableCell>
                  <div>
                    <p className="font-medium">{item.product}</p>
                    <p className="text-sm text-gray-500">{item.category}</p>
                  </div>
                </TableCell>
                <TableCell className="font-mono text-sm">{item.sku}</TableCell>
                <TableCell>{item.stock}</TableCell>
                <TableCell>{item.reserved}</TableCell>
                <TableCell>{item.available}</TableCell>
                <TableCell>
                  <span className={item.available <= item.reorderLevel ? "text-red-600 font-medium" : ""}>
                    {item.reorderLevel}
                  </span>
                </TableCell>
                <TableCell>
                  <Badge className={getStatusColor(item.status)}>{item.status.replace("_", " ")}</Badge>
                </TableCell>
                <TableCell>{item.lastRestocked}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Recent Stock Movements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileText className="mr-2 h-5 w-5" />
            Recent Stock Movements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {stockMovements.map((movement) => (
              <div key={movement.id} className="flex items-center justify-between border-b pb-4">
                <div>
                  <p className="font-medium">{movement.product}</p>
                  <p className="text-sm text-gray-500">{movement.reason}</p>
                </div>
                <div className="text-right">
                  <p className={`font-medium ${getMovementColor(movement.type)}`}>
                    {movement.type === "in" ? "+" : movement.type === "out" ? "-" : "±"}
                    {Math.abs(movement.quantity)}
                  </p>
                  <p className="text-sm text-gray-500">{movement.date}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
