"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, Star, Flag, MessageSquare, Eye, CheckCircle, XCircle, AlertTriangle } from "lucide-react"

const reviews = [
  {
    id: 1,
    customer: "Nguyễn Văn A",
    avatar: "/placeholder.svg?height=40&width=40",
    product: "BLACK SIDE PLEAT WIDE LEG JEANS",
    productImage: "/placeholder.svg?height=60&width=60",
    rating: 5,
    title: "Sản phẩm rất tốt!",
    content:
      "Chất lượng vải rất đẹp, form dáng vừa vặn. Tôi rất hài lòng với sản phẩm này. Sẽ mua thêm những sản phẩm khác.",
    date: "2023-06-15",
    status: "approved",
    helpful: 12,
    reported: 0,
    verified: true,
  },
  {
    id: 2,
    customer: "Trần Thị B",
    avatar: "/placeholder.svg?height=40&width=40",
    product: "BLACK CUT-OUT LONG SLEEVE SHIRT",
    productImage: "/placeholder.svg?height=60&width=60",
    rating: 4,
    title: "Đẹp nhưng hơi mỏng",
    content: "Áo đẹp, thiết kế độc đáo nhưng vải hơi mỏng so với mong đợi. Nhìn chung vẫn ok.",
    date: "2023-06-14",
    status: "pending",
    helpful: 5,
    reported: 1,
    verified: true,
  },
  {
    id: 3,
    customer: "Lê Văn C",
    avatar: "/placeholder.svg?height=40&width=40",
    product: "SMUDGE STRAIGHT FIT JEANS",
    productImage: "/placeholder.svg?height=60&width=60",
    rating: 2,
    title: "Không như mong đợi",
    content: "Sản phẩm không giống hình. Chất lượng kém, may không chắc chắn. Rất thất vọng.",
    date: "2023-06-13",
    status: "flagged",
    helpful: 2,
    reported: 3,
    verified: false,
  },
]

export default function ReviewsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isReplyOpen, setIsReplyOpen] = useState(false)
  const [selectedReview, setSelectedReview] = useState(null)

  const getStatusColor = (status) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "flagged":
        return "bg-red-100 text-red-800"
      case "rejected":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "pending":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case "flagged":
        return <Flag className="h-4 w-4 text-red-600" />
      case "rejected":
        return <XCircle className="h-4 w-4 text-gray-600" />
      default:
        return null
    }
  }

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star key={i} className={`h-4 w-4 ${i < rating ? "text-yellow-400 fill-current" : "text-gray-300"}`} />
    ))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Reviews Management</h1>
        <Dialog open={isReplyOpen} onOpenChange={setIsReplyOpen}>
          <DialogTrigger asChild>
            <Button>
              <MessageSquare className="mr-2 h-4 w-4" />
              Reply to Review
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reply to Customer Review</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Select Review</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a review to reply to" />
                  </SelectTrigger>
                  <SelectContent>
                    {reviews.map((review) => (
                      <SelectItem key={review.id} value={review.id.toString()}>
                        {review.customer} - {review.product}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Your Reply</Label>
                <Textarea
                  placeholder="Thank you for your feedback. We appreciate your review..."
                  className="min-h-[100px]"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsReplyOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setIsReplyOpen(false)}>Send Reply</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Reviews</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,234</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
            <Star className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.6</div>
            <div className="flex items-center mt-1">{renderStars(5)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Reviews</CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">23</div>
            <p className="text-xs text-muted-foreground">Awaiting moderation</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Flagged Reviews</CardTitle>
            <Flag className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <p className="text-xs text-muted-foreground">Requires attention</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex items-center space-x-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search reviews..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Rating" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Ratings</SelectItem>
            <SelectItem value="5">5 Stars</SelectItem>
            <SelectItem value="4">4 Stars</SelectItem>
            <SelectItem value="3">3 Stars</SelectItem>
            <SelectItem value="2">2 Stars</SelectItem>
            <SelectItem value="1">1 Star</SelectItem>
          </SelectContent>
        </Select>
        <Select>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="flagged">Flagged</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
        <Select>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Verified" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Reviews</SelectItem>
            <SelectItem value="verified">Verified Purchase</SelectItem>
            <SelectItem value="unverified">Unverified</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Reviews Table */}
      <div className="rounded-md border bg-white">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Review</TableHead>
              <TableHead>Product</TableHead>
              <TableHead>Rating</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Engagement</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {reviews.map((review) => (
              <TableRow key={review.id}>
                <TableCell>
                  <div className="flex items-start space-x-3">
                    <Avatar>
                      <AvatarImage src={review.avatar || "/placeholder.svg"} alt={review.customer} />
                      <AvatarFallback>{review.customer.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <p className="font-medium text-sm">{review.customer}</p>
                        {review.verified && (
                          <Badge variant="outline" className="text-xs">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Verified
                          </Badge>
                        )}
                      </div>
                      <p className="font-medium text-sm mt-1">{review.title}</p>
                      <p className="text-sm text-gray-600 mt-1 line-clamp-2">{review.content}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <Image
                      src={review.productImage || "/placeholder.svg"}
                      alt={review.product}
                      width={40}
                      height={40}
                      className="rounded object-cover"
                    />
                    <div>
                      <p className="font-medium text-sm">{review.product}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-1">
                    {renderStars(review.rating)}
                    <span className="ml-2 text-sm font-medium">{review.rating}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    {getStatusIcon(review.status)}
                    <Badge className={`ml-2 ${getStatusColor(review.status)}`}>{review.status}</Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="text-sm">
                    <p className="text-green-600">{review.helpful} helpful</p>
                    {review.reported > 0 && <p className="text-red-600">{review.reported} reported</p>}
                  </div>
                </TableCell>
                <TableCell>{review.date}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                    {review.status === "pending" && (
                      <>
                        <Button variant="ghost" size="sm">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <XCircle className="h-4 w-4 text-red-600" />
                        </Button>
                      </>
                    )}
                    {review.status === "flagged" && (
                      <Button variant="ghost" size="sm">
                        <Flag className="h-4 w-4 text-red-600" />
                      </Button>
                    )}
                    <Button variant="ghost" size="sm">
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
