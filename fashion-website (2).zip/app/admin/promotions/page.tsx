"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, Plus, Tag, Calendar, Percent, Gift } from "lucide-react"

const promotions = [
  {
    id: 1,
    code: "SUMMER2023",
    name: "Summer Sale",
    type: "percentage",
    value: 20,
    minOrder: "500,000 Đ",
    maxDiscount: "200,000 Đ",
    usageLimit: 100,
    usageCount: 45,
    startDate: "2023-06-01",
    endDate: "2023-08-31",
    status: "active",
  },
  {
    id: 2,
    code: "FREESHIP50",
    name: "Free Shipping",
    type: "free_shipping",
    value: 0,
    minOrder: "300,000 Đ",
    maxDiscount: "50,000 Đ",
    usageLimit: 200,
    usageCount: 89,
    startDate: "2023-06-15",
    endDate: "2023-12-31",
    status: "active",
  },
  {
    id: 3,
    code: "NEWUSER",
    name: "New User Discount",
    type: "fixed",
    value: 100000,
    minOrder: "200,000 Đ",
    maxDiscount: "100,000 Đ",
    usageLimit: 50,
    usageCount: 50,
    startDate: "2023-01-01",
    endDate: "2023-12-31",
    status: "expired",
  },
]

export default function PromotionsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddPromotionOpen, setIsAddPromotionOpen] = useState(false)
  const [promotionType, setPromotionType] = useState("percentage")

  const getStatusColor = (status) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "expired":
        return "bg-red-100 text-red-800"
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const formatValue = (type, value) => {
    switch (type) {
      case "percentage":
        return `${value}%`
      case "fixed":
        return `${value.toLocaleString()} Đ`
      case "free_shipping":
        return "Free Shipping"
      default:
        return value
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Promotions & Discounts</h1>
        <Dialog open={isAddPromotionOpen} onOpenChange={setIsAddPromotionOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Promotion
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Promotion</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Basic Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Basic Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Promotion Name</Label>
                    <Input placeholder="e.g., Summer Sale" />
                  </div>
                  <div className="space-y-2">
                    <Label>Promotion Code</Label>
                    <Input placeholder="e.g., SUMMER2023" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea placeholder="Promotion description..." />
                </div>
              </div>

              {/* Discount Settings */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Discount Settings</h3>
                <div className="space-y-2">
                  <Label>Discount Type</Label>
                  <Select value={promotionType} onValueChange={setPromotionType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">Percentage Discount</SelectItem>
                      <SelectItem value="fixed">Fixed Amount</SelectItem>
                      <SelectItem value="free_shipping">Free Shipping</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {promotionType !== "free_shipping" && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>
                        {promotionType === "percentage" ? "Discount Percentage (%)" : "Discount Amount (VND)"}
                      </Label>
                      <Input type="number" placeholder={promotionType === "percentage" ? "20" : "100000"} />
                    </div>
                    <div className="space-y-2">
                      <Label>Maximum Discount (VND)</Label>
                      <Input type="number" placeholder="200000" />
                    </div>
                  </div>
                )}
              </div>

              {/* Conditions */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Conditions</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Minimum Order Value (VND)</Label>
                    <Input type="number" placeholder="500000" />
                  </div>
                  <div className="space-y-2">
                    <Label>Usage Limit</Label>
                    <Input type="number" placeholder="100" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Date</Label>
                    <Input type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label>End Date</Label>
                    <Input type="date" />
                  </div>
                </div>
              </div>

              {/* Additional Options */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Additional Options</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="first-time" />
                    <Label htmlFor="first-time">First-time customers only</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="auto-apply" />
                    <Label htmlFor="auto-apply">Auto-apply when conditions are met</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="stackable" />
                    <Label htmlFor="stackable">Can be combined with other promotions</Label>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsAddPromotionOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setIsAddPromotionOpen(false)}>Create Promotion</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Promotions</CardTitle>
            <Tag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-muted-foreground">Currently running</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Usage</CardTitle>
            <Gift className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,234</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Discount</CardTitle>
            <Percent className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">45.2M Đ</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">Within 7 days</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex items-center space-x-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search promotions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="expired">Expired</SelectItem>
            <SelectItem value="scheduled">Scheduled</SelectItem>
          </SelectContent>
        </Select>
        <Select>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="percentage">Percentage</SelectItem>
            <SelectItem value="fixed">Fixed Amount</SelectItem>
            <SelectItem value="free_shipping">Free Shipping</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Promotions Table */}
      <div className="rounded-md border bg-white">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Promotion</TableHead>
              <TableHead>Code</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Value</TableHead>
              <TableHead>Usage</TableHead>
              <TableHead>Period</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {promotions.map((promotion) => (
              <TableRow key={promotion.id}>
                <TableCell>
                  <div>
                    <p className="font-medium">{promotion.name}</p>
                    <p className="text-sm text-gray-500">Min order: {promotion.minOrder}</p>
                  </div>
                </TableCell>
                <TableCell className="font-mono">{promotion.code}</TableCell>
                <TableCell className="capitalize">{promotion.type.replace("_", " ")}</TableCell>
                <TableCell>{formatValue(promotion.type, promotion.value)}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <span>
                      {promotion.usageCount}/{promotion.usageLimit}
                    </span>
                    <div className="w-16 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${(promotion.usageCount / promotion.usageLimit) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="text-sm">
                    <p>{promotion.startDate}</p>
                    <p className="text-gray-500">to {promotion.endDate}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className={getStatusColor(promotion.status)}>{promotion.status}</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm">
                      Edit
                    </Button>
                    <Button variant="ghost" size="sm">
                      Duplicate
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
