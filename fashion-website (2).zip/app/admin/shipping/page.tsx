"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, Plus, MapPin, Phone, Star, Edit } from "lucide-react"

const shippingMethods = [
  {
    id: 1,
    name: "Standard Delivery",
    fee: "30,000 Đ",
    estimatedTime: "3-5 days",
    status: "active",
    description: "Regular delivery service",
  },
  {
    id: 2,
    name: "Express Delivery",
    fee: "50,000 Đ",
    estimatedTime: "1-2 days",
    status: "active",
    description: "Fast delivery service",
  },
  {
    id: 3,
    name: "Same Day Delivery",
    fee: "100,000 Đ",
    estimatedTime: "Same day",
    status: "active",
    description: "Within Ho Chi Minh City only",
  },
  {
    id: 4,
    name: "Free Shipping",
    fee: "0 Đ",
    estimatedTime: "5-7 days",
    status: "active",
    description: "For orders over 1,000,000 Đ",
  },
]

const shippers = [
  {
    id: 1,
    name: "Nguyễn Văn A",
    phone: "+84 123 456 789",
    vehicle: "Honda Wave",
    rating: 4.8,
    totalDeliveries: 245,
    status: "active",
    currentLocation: "Quận 1, TP.HCM",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 2,
    name: "Trần Thị B",
    phone: "+84 987 654 321",
    vehicle: "Yamaha Sirius",
    rating: 4.9,
    totalDeliveries: 189,
    status: "active",
    currentLocation: "Quận 3, TP.HCM",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 3,
    name: "Lê Văn C",
    phone: "+84 555 123 456",
    vehicle: "Honda Air Blade",
    rating: 4.6,
    totalDeliveries: 156,
    status: "offline",
    currentLocation: "Quận 10, TP.HCM",
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

export default function ShippingPage() {
  const [activeTab, setActiveTab] = useState("methods")
  const [isAddMethodOpen, setIsAddMethodOpen] = useState(false)
  const [isAddShipperOpen, setIsAddShipperOpen] = useState(false)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Shipping Management</h1>
        <div className="flex space-x-2">
          <Dialog open={isAddMethodOpen} onOpenChange={setIsAddMethodOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Shipping Method
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Shipping Method</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Method Name</Label>
                  <Input placeholder="e.g., Express Delivery" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Shipping Fee (VND)</Label>
                    <Input type="number" placeholder="0" />
                  </div>
                  <div className="space-y-2">
                    <Label>Estimated Time</Label>
                    <Input placeholder="e.g., 1-2 days" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea placeholder="Method description..." />
                </div>
                <div className="space-y-2">
                  <Label>Conditions</Label>
                  <Textarea placeholder="e.g., For orders over 500,000 Đ" />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddMethodOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsAddMethodOpen(false)}>Add Method</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isAddShipperOpen} onOpenChange={setIsAddShipperOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="mr-2 h-4 w-4" />
                Add Shipper
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Shipper</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Full Name</Label>
                    <Input placeholder="Shipper name" />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone Number</Label>
                    <Input placeholder="+84 xxx xxx xxx" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Vehicle Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select vehicle" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="motorbike">Motorbike</SelectItem>
                        <SelectItem value="bicycle">Bicycle</SelectItem>
                        <SelectItem value="car">Car</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Vehicle Model</Label>
                    <Input placeholder="e.g., Honda Wave" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>License Plate</Label>
                  <Input placeholder="e.g., 59A1-12345" />
                </div>
                <div className="space-y-2">
                  <Label>Working Area</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select area" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="district1">Quận 1</SelectItem>
                      <SelectItem value="district3">Quận 3</SelectItem>
                      <SelectItem value="district10">Quận 10</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddShipperOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsAddShipperOpen(false)}>Add Shipper</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab("methods")}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === "methods"
                ? "border-black text-black"
                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
          >
            Shipping Methods
          </button>
          <button
            onClick={() => setActiveTab("shippers")}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === "shippers"
                ? "border-black text-black"
                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
          >
            Shippers
          </button>
        </nav>
      </div>

      {/* Shipping Methods Tab */}
      {activeTab === "methods" && (
        <div className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {shippingMethods.map((method) => (
              <Card key={method.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{method.name}</CardTitle>
                    <Badge variant={method.status === "active" ? "default" : "secondary"}>{method.status}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Fee:</span>
                      <span className="font-medium">{method.fee}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Time:</span>
                      <span className="font-medium">{method.estimatedTime}</span>
                    </div>
                    <p className="text-sm text-gray-600 mt-2">{method.description}</p>
                    <Button variant="outline" size="sm" className="w-full mt-4">
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Shippers Tab */}
      {activeTab === "shippers" && (
        <div className="space-y-6">
          {/* Search */}
          <div className="flex items-center space-x-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <Input placeholder="Search shippers..." className="pl-10" />
            </div>
            <Select>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="offline">Offline</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Shippers Table */}
          <div className="rounded-md border bg-white">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Shipper</TableHead>
                  <TableHead>Vehicle</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Deliveries</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {shippers.map((shipper) => (
                  <TableRow key={shipper.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarImage src={shipper.avatar || "/placeholder.svg"} alt={shipper.name} />
                          <AvatarFallback>{shipper.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{shipper.name}</p>
                          <p className="text-sm text-gray-500">{shipper.phone}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{shipper.vehicle}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-400 mr-1" />
                        {shipper.rating}
                      </div>
                    </TableCell>
                    <TableCell>{shipper.totalDeliveries}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 text-gray-400 mr-1" />
                        {shipper.currentLocation}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={shipper.status === "active" ? "default" : "secondary"}>{shipper.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          <Phone className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <MapPin className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </div>
  )
}
