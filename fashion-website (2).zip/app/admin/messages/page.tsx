"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Search, Send, Paperclip, MoreHorizontal, Star, Archive, Tag } from "lucide-react"

const conversations = [
  {
    id: 1,
    customer: "Nguyễn Văn A",
    email: "nguyenvana@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Tôi muốn hỏi về sản phẩm BLACK SIDE PLEAT WIDE LEG JEANS",
    timestamp: "10:30 AM",
    unread: true,
    priority: "normal",
    tags: ["product_inquiry"],
  },
  {
    id: 2,
    customer: "Trần Thị B",
    email: "tranthib@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Đơn hàng của tôi đã được giao chưa ạ?",
    timestamp: "9:15 AM",
    unread: true,
    priority: "high",
    tags: ["order_status"],
  },
  {
    id: 3,
    customer: "Lê Văn C",
    email: "levanc@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Cảm ơn bạn đã hỗ trợ!",
    timestamp: "Yesterday",
    unread: false,
    priority: "normal",
    tags: ["resolved"],
  },
]

const messages = [
  {
    id: 1,
    sender: "customer",
    content: "Chào bạn, tôi muốn hỏi về sản phẩm BLACK SIDE PLEAT WIDE LEG JEANS. Sản phẩm này có size M không ạ?",
    timestamp: "10:25 AM",
    attachments: [],
  },
  {
    id: 2,
    sender: "admin",
    content:
      "Chào anh/chị! Cảm ơn anh/chị đã quan tâm đến sản phẩm của chúng tôi. Hiện tại sản phẩm BLACK SIDE PLEAT WIDE LEG JEANS vẫn còn size M. Anh/chị có muốn tôi kiểm tra tồn kho chi tiết không ạ?",
    timestamp: "10:27 AM",
    attachments: [],
  },
  {
    id: 3,
    sender: "customer",
    content: "Vâng, bạn có thể kiểm tra giúp tôi được không? Và cho tôi biết thêm về chất liệu của sản phẩm này.",
    timestamp: "10:30 AM",
    attachments: [],
  },
]

export default function MessagesPage() {
  const [selectedConversation, setSelectedConversation] = useState(conversations[0])
  const [newMessage, setNewMessage] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "normal":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTagColor = (tag) => {
    switch (tag) {
      case "product_inquiry":
        return "bg-blue-100 text-blue-800"
      case "order_status":
        return "bg-purple-100 text-purple-800"
      case "complaint":
        return "bg-red-100 text-red-800"
      case "resolved":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // Add message logic here
      setNewMessage("")
    }
  }

  return (
    <div className="h-[calc(100vh-8rem)] flex">
      {/* Conversations List */}
      <div className="w-1/3 border-r border-gray-200 bg-white">
        <div className="p-4 border-b border-gray-200">
          <h1 className="text-xl font-bold mb-4">Messages</h1>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex space-x-2 mt-4">
            <Select>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Messages</SelectItem>
                <SelectItem value="unread">Unread</SelectItem>
                <SelectItem value="high_priority">High Priority</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="overflow-y-auto">
          {conversations.map((conversation) => (
            <div
              key={conversation.id}
              className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${
                selectedConversation?.id === conversation.id ? "bg-blue-50 border-blue-200" : ""
              }`}
              onClick={() => setSelectedConversation(conversation)}
            >
              <div className="flex items-start space-x-3">
                <Avatar>
                  <AvatarImage src={conversation.avatar || "/placeholder.svg"} alt={conversation.customer} />
                  <AvatarFallback>{conversation.customer.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-sm truncate">{conversation.customer}</p>
                    <div className="flex items-center space-x-1">
                      {conversation.unread && <div className="w-2 h-2 bg-blue-600 rounded-full"></div>}
                      <span className="text-xs text-gray-500">{conversation.timestamp}</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 truncate mt-1">{conversation.lastMessage}</p>
                  <div className="flex items-center space-x-2 mt-2">
                    <Badge className={getPriorityColor(conversation.priority)} variant="outline">
                      {conversation.priority}
                    </Badge>
                    {conversation.tags.map((tag) => (
                      <Badge key={tag} className={getTagColor(tag)} variant="outline">
                        {tag.replace("_", " ")}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-200 bg-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage
                      src={selectedConversation.avatar || "/placeholder.svg"}
                      alt={selectedConversation.customer}
                    />
                    <AvatarFallback>{selectedConversation.customer.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h2 className="font-medium">{selectedConversation.customer}</h2>
                    <p className="text-sm text-gray-500">{selectedConversation.email}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm">
                    <Star className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Archive className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Tag className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === "admin" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                      message.sender === "admin"
                        ? "bg-blue-600 text-white"
                        : "bg-white text-gray-900 border border-gray-200"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p className={`text-xs mt-1 ${message.sender === "admin" ? "text-blue-100" : "text-gray-500"}`}>
                      {message.timestamp}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-gray-200 bg-white">
              <div className="flex items-end space-x-2">
                <div className="flex-1">
                  <Textarea
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    className="min-h-[60px] resize-none"
                    onKeyPress={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault()
                        handleSendMessage()
                      }
                    }}
                  />
                </div>
                <div className="flex flex-col space-y-2">
                  <Button variant="ghost" size="sm">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center space-x-2 mt-2">
                <Select>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Quick reply" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="greeting">Greeting</SelectItem>
                    <SelectItem value="product_info">Product Info</SelectItem>
                    <SelectItem value="shipping_info">Shipping Info</SelectItem>
                    <SelectItem value="closing">Closing</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm">
                  <Tag className="mr-2 h-4 w-4" />
                  Add Tag
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <h3 className="text-lg font-medium text-gray-900">No conversation selected</h3>
              <p className="text-gray-500">Choose a conversation from the list to start messaging</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
