"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Search, Eye, Printer, MapPin, Phone, Edit, Truck } from "lucide-react"

const orders = [
  {
    id: "ORD-12345",
    customer: "Nguyễn Văn A",
    products: "BLACK SIDE PLEAT WIDE LEG JEANS, BLACK CUT-OUT LONG SLEEVE SHIRT",
    shipper: "Trần Văn B",
    total: "1,580,000 Đ",
    status: "processing",
    date: "2023-06-15",
    phone: "+84 123 456 789",
    address: "123 Nguyễn Huệ, Quận 1, TP.HCM",
  },
  {
    id: "ORD-12346",
    customer: "Trần Thị C",
    products: "SMUDGE STRAIGHT FIT JEANS",
    shipper: "Lê Văn D",
    total: "950,000 Đ",
    status: "shipping",
    date: "2023-06-14",
    phone: "+84 987 654 321",
    address: "456 Lê Lợi, Quận 3, TP.HCM",
  },
  {
    id: "ORD-12347",
    customer: "Phạm Văn E",
    products: "MINIMALIST SILK BLOUSE",
    shipper: "Hoàng Thị F",
    total: "1,200,000 Đ",
    status: "delivered",
    date: "2023-06-13",
    phone: "+84 555 123 456",
    address: "789 Võ Văn Tần, Quận 10, TP.HCM",
  },
]

export default function OrdersPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedOrder, setSelectedOrder] = useState(null)
  const [isUpdateStatusOpen, setIsUpdateStatusOpen] = useState(false)
  const [isAssignShipperOpen, setIsAssignShipperOpen] = useState(false)

  const getStatusColor = (status) => {
    switch (status) {
      case "processing":
        return "bg-yellow-100 text-yellow-800"
      case "shipping":
        return "bg-blue-100 text-blue-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const filteredOrders = orders.filter(
    (order) =>
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleUpdateStatus = (order) => {
    setSelectedOrder(order)
    setIsUpdateStatusOpen(true)
  }

  const handleAssignShipper = (order) => {
    setSelectedOrder(order)
    setIsAssignShipperOpen(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Orders</h1>
        <Button>
          <Printer className="mr-2 h-4 w-4" />
          Export Orders
        </Button>
      </div>

      {/* Search and Filters */}
      <div className="flex items-center space-x-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search orders..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="processing">Processing</SelectItem>
            <SelectItem value="shipping">Shipping</SelectItem>
            <SelectItem value="delivered">Delivered</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
        <Select>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Date Range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
            <SelectItem value="custom">Custom Range</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Orders Table */}
      <div className="rounded-md border bg-white">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order ID</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Products</TableHead>
              <TableHead>Shipper</TableHead>
              <TableHead>Total</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredOrders.map((order) => (
              <TableRow key={order.id}>
                <TableCell className="font-medium">{order.id}</TableCell>
                <TableCell>{order.customer}</TableCell>
                <TableCell className="max-w-xs truncate">{order.products}</TableCell>
                <TableCell>{order.shipper}</TableCell>
                <TableCell>{order.total}</TableCell>
                <TableCell>
                  <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Sheet>
                      <SheetTrigger asChild>
                        <Button variant="ghost" size="sm" onClick={() => setSelectedOrder(order)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                      </SheetTrigger>
                      <SheetContent className="w-[600px] sm:max-w-[600px]">
                        <SheetHeader>
                          <SheetTitle>Order Details</SheetTitle>
                          <SheetDescription>View and manage order {order.id}</SheetDescription>
                        </SheetHeader>

                        {selectedOrder && (
                          <div className="mt-6 space-y-6">
                            {/* Order Status Timeline */}
                            <div className="space-y-4">
                              <h3 className="text-lg font-medium">Order Status</h3>
                              <div className="relative">
                                <div className="absolute left-4 top-8 h-full w-0.5 bg-gray-200"></div>
                                <div className="space-y-6">
                                  {[
                                    { status: "Order Placed", completed: true, date: "2023-06-15 10:30" },
                                    { status: "Processing", completed: true, date: "2023-06-15 11:00" },
                                    {
                                      status: "Shipped",
                                      completed: order.status !== "processing",
                                      date: order.status !== "processing" ? "2023-06-15 14:30" : null,
                                    },
                                    {
                                      status: "Delivered",
                                      completed: order.status === "delivered",
                                      date: order.status === "delivered" ? "2023-06-16 09:15" : null,
                                    },
                                  ].map((step, index) => (
                                    <div key={index} className="relative flex items-center">
                                      <div
                                        className={`relative z-10 h-8 w-8 rounded-full border-2 ${
                                          step.completed ? "border-black bg-black" : "border-gray-300 bg-white"
                                        } flex items-center justify-center`}
                                      >
                                        {step.completed && <div className="h-2 w-2 rounded-full bg-white"></div>}
                                      </div>
                                      <div className="ml-4">
                                        <p className={`font-medium ${step.completed ? "text-black" : "text-gray-500"}`}>
                                          {step.status}
                                        </p>
                                        {step.date && <p className="text-sm text-gray-500">{step.date}</p>}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>

                            {/* Customer Information */}
                            <div className="space-y-4">
                              <h3 className="text-lg font-medium">Customer Information</h3>
                              <div className="rounded-lg border p-4">
                                <p className="font-medium">{selectedOrder.customer}</p>
                                <p className="text-sm text-gray-600">{selectedOrder.phone}</p>
                                <p className="text-sm text-gray-600">{selectedOrder.address}</p>
                              </div>
                            </div>

                            {/* Shipper Information */}
                            <div className="space-y-4">
                              <h3 className="text-lg font-medium">Shipper Information</h3>
                              <div className="rounded-lg border p-4">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <p className="font-medium">{selectedOrder.shipper}</p>
                                    <p className="text-sm text-gray-600">Honda Wave</p>
                                  </div>
                                  <div className="flex space-x-2">
                                    <Button variant="outline" size="sm">
                                      <Phone className="mr-2 h-4 w-4" />
                                      Call
                                    </Button>
                                    <Button variant="outline" size="sm">
                                      <MapPin className="mr-2 h-4 w-4" />
                                      Track
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Order Items */}
                            <div className="space-y-4">
                              <h3 className="text-lg font-medium">Order Items</h3>
                              <div className="rounded-lg border p-4">
                                <p className="text-sm">{selectedOrder.products}</p>
                                <div className="mt-4 flex justify-between border-t pt-4">
                                  <span className="font-medium">Total:</span>
                                  <span className="font-medium">{selectedOrder.total}</span>
                                </div>
                              </div>
                            </div>

                            {/* Actions */}
                            <div className="flex space-x-2">
                              <Button className="flex-1" onClick={() => handleUpdateStatus(selectedOrder)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Update Status
                              </Button>
                              <Button variant="outline" onClick={() => handleAssignShipper(selectedOrder)}>
                                <Truck className="mr-2 h-4 w-4" />
                                Assign Shipper
                              </Button>
                              <Button variant="outline">
                                <Printer className="mr-2 h-4 w-4" />
                                Print Invoice
                              </Button>
                            </div>
                          </div>
                        )}
                      </SheetContent>
                    </Sheet>
                    <Button variant="ghost" size="sm" onClick={() => handleUpdateStatus(order)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Printer className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Update Status Modal */}
      <Dialog open={isUpdateStatusOpen} onOpenChange={setIsUpdateStatusOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Order Status</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Order ID</Label>
              <Input value={selectedOrder?.id} disabled />
            </div>
            <div className="space-y-2">
              <Label>Current Status</Label>
              <Input value={selectedOrder?.status} disabled />
            </div>
            <div className="space-y-2">
              <Label>New Status</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select new status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="processing">Processing</SelectItem>
                  <SelectItem value="shipping">Shipping</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea placeholder="Add notes about status change..." />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsUpdateStatusOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsUpdateStatusOpen(false)}>Update Status</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Assign Shipper Modal */}
      <Dialog open={isAssignShipperOpen} onOpenChange={setIsAssignShipperOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Shipper</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Order ID</Label>
              <Input value={selectedOrder?.id} disabled />
            </div>
            <div className="space-y-2">
              <Label>Current Shipper</Label>
              <Input value={selectedOrder?.shipper} disabled />
            </div>
            <div className="space-y-2">
              <Label>New Shipper</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select shipper" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="shipper1">Nguyễn Văn A - Honda Wave</SelectItem>
                  <SelectItem value="shipper2">Trần Thị B - Yamaha Sirius</SelectItem>
                  <SelectItem value="shipper3">Lê Văn C - Honda Air Blade</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Delivery Instructions</Label>
              <Textarea placeholder="Special delivery instructions..." />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsAssignShipperOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsAssignShipperOpen(false)}>Assign Shipper</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
