"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Grid, List, ChevronDown, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { motion } from "framer-motion"

const allProducts = [
  {
    id: 1,
    name: "BLACK SIDE PLEAT WIDE LEG JEANS",
    price: "890,000 Đ",
    originalPrice: null,
    image: "/placeholder.svg?height=600&width=480",
    category: "Bottoms",
    collection: "Spring Summer 2024",
    isNew: true,
    onSale: false,
  },
  {
    id: 2,
    name: "BLACK CUT-OUT LONG SLEEVE SHIRT",
    price: "690,000 Đ",
    originalPrice: null,
    image: "/placeholder.svg?height=600&width=480",
    category: "Tops",
    collection: "Spring Summer 2024",
    isNew: true,
    onSale: false,
  },
  {
    id: 3,
    name: "SMUDGE STRAIGHT FIT JEANS",
    price: "950,000 Đ",
    originalPrice: null,
    image: "/placeholder.svg?height=600&width=480",
    category: "Bottoms",
    collection: "Spring Summer 2024",
    isNew: true,
    onSale: false,
  },
  {
    id: 4,
    name: "MINIMALIST SILK BLOUSE",
    price: "1,200,000 Đ",
    originalPrice: null,
    image: "/placeholder.svg?height=600&width=480",
    category: "Tops",
    collection: "Essentials",
    isNew: false,
    onSale: false,
  },
  {
    id: 5,
    name: "TAILORED WOOL TROUSERS",
    price: "1,800,000 Đ",
    originalPrice: null,
    image: "/placeholder.svg?height=600&width=480",
    category: "Bottoms",
    collection: "Essentials",
    isNew: false,
    onSale: false,
  },
  {
    id: 6,
    name: "STRUCTURED CANVAS TOTE",
    price: "750,000 Đ",
    originalPrice: "950,000 Đ",
    image: "/placeholder.svg?height=600&width=480",
    category: "Accessories",
    collection: "Essentials",
    isNew: false,
    onSale: true,
  },
]

const categories = ["All", "Tops", "Bottoms", "Outerwear", "Accessories"]
const collections = ["All", "Spring Summer 2024", "Essentials", "Winter 2023"]
const sortOptions = ["Featured", "Price: Low to High", "Price: High to Low", "Newest", "Best Selling", "A-Z", "Z-A"]

export default function AllProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedCollection, setSelectedCollection] = useState("All")
  const [sortBy, setSortBy] = useState("Featured")
  const [viewMode, setViewMode] = useState("grid")
  const [searchQuery, setSearchQuery] = useState("")
  const [showFilters, setShowFilters] = useState(false)

  const filteredProducts = allProducts.filter((product) => {
    const matchesCategory = selectedCategory === "All" || product.category === selectedCategory
    const matchesCollection = selectedCollection === "All" || product.collection === selectedCollection
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase())

    return matchesCategory && matchesCollection && matchesSearch
  })

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    const priceA = Number.parseInt(a.price.replace(/[^\d]/g, ""))
    const priceB = Number.parseInt(b.price.replace(/[^\d]/g, ""))

    switch (sortBy) {
      case "Price: Low to High":
        return priceA - priceB
      case "Price: High to Low":
        return priceB - priceA
      case "A-Z":
        return a.name.localeCompare(b.name)
      case "Z-A":
        return b.name.localeCompare(a.name)
      case "Newest":
        return b.isNew ? 1 : -1
      default:
        return 0
    }
  })

  return (
    <main className="pt-24">
      <div className="container mx-auto px-8 py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="font-serif text-3xl font-light md:text-4xl">All Products</h1>
          <p className="mt-4 text-gray-600 text-base">Explore our complete collection of minimalist fashion</p>
        </div>

        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <Input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 text-base"
            />
          </div>
        </div>

        {/* Filters and Sort */}
        <div className="mb-8 space-y-4 border-b border-gray-200 pb-6">
          {/* Desktop Filters */}
          <div className="hidden md:flex md:flex-wrap md:gap-4">
            {/* Category Filter */}
            <div className="flex gap-2">
              <span className="flex items-center text-base font-medium text-gray-700">Category:</span>
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-3 py-1 text-base transition-colors ${
                    selectedCategory === category
                      ? "bg-black text-white"
                      : "border border-gray-300 text-gray-700 hover:border-black"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            {/* Collection Filter */}
            <div className="flex gap-2">
              <span className="flex items-center text-base font-medium text-gray-700">Collection:</span>
              {collections.map((collection) => (
                <button
                  key={collection}
                  onClick={() => setSelectedCollection(collection)}
                  className={`px-3 py-1 text-base transition-colors ${
                    selectedCollection === collection
                      ? "bg-black text-white"
                      : "border border-gray-300 text-gray-700 hover:border-black"
                  }`}
                >
                  {collection}
                </button>
              ))}
            </div>
          </div>

          {/* Sort and View Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* Sort Dropdown */}
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="appearance-none border border-gray-300 bg-white px-4 py-2 pr-8 text-base focus:border-black focus:outline-none"
                >
                  {sortOptions.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-2 top-1/2 h-4 w-4 -translate-y-1/2 pointer-events-none" />
              </div>

              {/* Products Count */}
              <p className="text-base text-gray-600">{sortedProducts.length} products</p>
            </div>

            {/* View Mode Toggle */}
            <div className="flex border border-gray-300">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 ${viewMode === "grid" ? "bg-black text-white" : "text-gray-700"}`}
              >
                <Grid className="h-4 w-4" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 ${viewMode === "list" ? "bg-black text-white" : "text-gray-700"}`}
              >
                <List className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className={`grid gap-6 ${viewMode === "grid" ? "grid-cols-3" : "grid-cols-1"}`}>
          {sortedProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              className={`group relative ${viewMode === "list" ? "flex gap-6" : ""}`}
            >
              <Link href={`/products/${product.id}`}>
                <div
                  className={`relative overflow-hidden bg-gray-100 ${
                    viewMode === "list" ? "h-64 w-48 flex-shrink-0" : "aspect-[3/4] w-full"
                  }`}
                >
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-105"
                  />

                  {/* Badges */}
                  <div className="absolute left-2 top-2 flex flex-col gap-1">
                    {product.isNew && <span className="bg-black px-2 py-1 text-xs text-white">NEW</span>}
                    {product.onSale && <span className="bg-red-600 px-2 py-1 text-xs text-white">SALE</span>}
                  </div>
                </div>

                <div className={`${viewMode === "list" ? "flex-1 py-2" : "mt-4"}`}>
                  <h3 className="font-serif text-base font-light uppercase tracking-wide">{product.name}</h3>
                  <div className="mt-2 flex items-center gap-2">
                    <p className="text-gray-600 text-base">{product.price}</p>
                    {product.originalPrice && (
                      <p className="text-sm text-gray-400 line-through">{product.originalPrice}</p>
                    )}
                  </div>
                  {viewMode === "list" && (
                    <div className="mt-2 space-y-1">
                      <p className="text-base text-gray-500">{product.category}</p>
                      <p className="text-base text-gray-500">{product.collection}</p>
                    </div>
                  )}
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Load More Button */}
        {sortedProducts.length > 0 && (
          <div className="mt-16 flex justify-center">
            <Button variant="outline" className="px-8 py-3 text-base">
              Load More Products
            </Button>
          </div>
        )}
      </div>
    </main>
  )
}
