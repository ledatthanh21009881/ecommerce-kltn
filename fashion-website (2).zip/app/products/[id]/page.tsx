import Image from "next/image"
import Link from "next/link"
import { Minus, Plus, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"

// This would normally come from a database or API
const product = {
  id: 1,
  name: "Minimalist Silk Blouse",
  price: "$120",
  description:
    "A timeless silk blouse with clean lines and a relaxed fit. Made from 100% mulberry silk for a luxurious feel and elegant drape.",
  details: ["100% Mulberry Silk", "Relaxed fit", "Button closure", "Dry clean only", "Made in Portugal"],
  sizes: ["XS", "S", "M", "L", "XL"],
  colors: ["White", "Black", "Beige"],
  images: [
    "/placeholder.svg?height=800&width=600",
    "/placeholder.svg?height=800&width=600",
    "/placeholder.svg?height=800&width=600",
    "/placeholder.svg?height=800&width=600",
  ],
}

export default function ProductPage({ params }) {
  return (
    <main className="pt-24">
      <div className="container mx-auto px-4 py-12">
        <div className="grid gap-12 lg:grid-cols-2">
          {/* Product Images */}
          <div className="space-y-4">
            {product.images.map((image, index) => (
              <div key={index} className="relative aspect-[4/5] w-full overflow-hidden">
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} - View ${index + 1}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>

          {/* Product Info */}
          <div className="sticky top-24 h-fit">
            <div className="space-y-6">
              <div>
                <h1 className="font-serif text-3xl font-light md:text-4xl">{product.name}</h1>
                <p className="mt-2 text-xl">{product.price}</p>
              </div>

              <p className="text-gray-600">{product.description}</p>

              {/* Color Selection */}
              <div>
                <h3 className="mb-3 text-sm font-medium uppercase tracking-wider">Color</h3>
                <div className="flex gap-3">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      className="h-10 border border-gray-300 px-4 py-2 text-sm transition-colors hover:border-black"
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selection */}
              <div>
                <h3 className="mb-3 text-sm font-medium uppercase tracking-wider">Size</h3>
                <div className="flex flex-wrap gap-3">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      className="h-10 w-10 border border-gray-300 text-sm transition-colors hover:border-black"
                    >
                      {size}
                    </button>
                  ))}
                </div>
                <Link href="/size-guide" className="mt-2 inline-block text-sm underline underline-offset-4">
                  Size Guide
                </Link>
              </div>

              {/* Quantity */}
              <div>
                <h3 className="mb-3 text-sm font-medium uppercase tracking-wider">Quantity</h3>
                <div className="flex h-10 w-32 items-center border border-gray-300">
                  <button className="flex h-full w-10 items-center justify-center border-r border-gray-300">
                    <Minus className="h-3 w-3" />
                  </button>
                  <div className="flex h-full flex-1 items-center justify-center text-sm">1</div>
                  <button className="flex h-full w-10 items-center justify-center border-l border-gray-300">
                    <Plus className="h-3 w-3" />
                  </button>
                </div>
              </div>

              {/* Add to Cart Button */}
              <Button className="h-12 w-full bg-black text-white hover:bg-gray-800">Add to Cart</Button>

              {/* Product Details */}
              <div className="border-t border-gray-200 pt-6">
                <details className="group">
                  <summary className="flex cursor-pointer items-center justify-between py-3">
                    <h3 className="text-sm font-medium uppercase tracking-wider">Product Details</h3>
                    <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" />
                  </summary>
                  <div className="pb-4 pt-2 text-sm text-gray-600">
                    <ul className="list-inside list-disc space-y-2">
                      {product.details.map((detail, index) => (
                        <li key={index}>{detail}</li>
                      ))}
                    </ul>
                  </div>
                </details>

                <details className="group border-t border-gray-200">
                  <summary className="flex cursor-pointer items-center justify-between py-3">
                    <h3 className="text-sm font-medium uppercase tracking-wider">Shipping & Returns</h3>
                    <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" />
                  </summary>
                  <div className="pb-4 pt-2 text-sm text-gray-600">
                    <p>Free standard shipping on all orders over $100. Delivery within 3-5 business days.</p>
                    <p className="mt-2">
                      We offer free returns within 30 days of purchase. Items must be unworn with original tags
                      attached.
                    </p>
                  </div>
                </details>

                <details className="group border-t border-gray-200">
                  <summary className="flex cursor-pointer items-center justify-between py-3">
                    <h3 className="text-sm font-medium uppercase tracking-wider">Care Instructions</h3>
                    <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" />
                  </summary>
                  <div className="pb-4 pt-2 text-sm text-gray-600">
                    <p>Dry clean only. Do not bleach. Iron on low heat if necessary. Store on a padded hanger.</p>
                  </div>
                </details>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
