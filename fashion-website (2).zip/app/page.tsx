import Link from "next/link"
import Image from "next/image"
import { ArrowRight, ChevronDown } from "lucide-react"
import ProductGrid from "@/components/product-grid"
import Newsletter from "@/components/newsletter"
import BrandStory from "@/components/brand-story"

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen w-full overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Fashion hero image"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-black/30" />
        </div>
        <div className="relative z-10 flex h-full flex-col items-center justify-center px-4 text-center text-white">
          <h1 className="font-serif text-4xl font-light tracking-wider sm:text-5xl md:text-6xl lg:text-7xl">
            Timeless Elegance
          </h1>
          <p className="mt-6 max-w-md text-lg font-light md:max-w-lg md:text-xl">
            Discover our curated collection of minimalist designs that transcend seasons
          </p>
          <Link
            href="/collections"
            className="mt-8 inline-flex items-center border border-white px-8 py-3 font-light tracking-wider transition-colors hover:bg-white hover:text-black"
          >
            Explore Collection
          </Link>
        </div>
        <div className="absolute bottom-8 left-0 right-0 flex justify-center">
          <ChevronDown className="h-8 w-8 animate-bounce text-white opacity-75" />
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <h2 className="mb-16 font-serif text-3xl font-light tracking-wider md:text-4xl">New Arrivals</h2>
          <ProductGrid />
          <div className="mt-16 flex justify-center">
            <Link
              href="/all-products"
              className="group inline-flex items-center border-b border-black px-2 py-1 font-light tracking-wider transition-colors hover:text-gray-600"
            >
              View All Products
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
      </section>

      {/* Brand Story */}
      <BrandStory />

      {/* Newsletter */}
      <Newsletter />
    </main>
  )
}
