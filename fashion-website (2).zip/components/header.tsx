"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, Search, ShoppingBag, User, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useMobile } from "@/hooks/use-mobile"

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isAccountMenuOpen, setIsAccountMenuOpen] = useState(false)
  const isMobile = useMobile()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        isScrolled ? "bg-white shadow-sm" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className={`md:hidden ${!isScrolled ? "text-white" : ""}`}
          onClick={() => setIsMenuOpen(true)}
        >
          <Menu className="h-6 w-6" />
          <span className="sr-only">Open menu</span>
        </Button>

        {/* Logo */}
        <Link href="/" className={`font-serif text-xl tracking-wider ${!isScrolled ? "text-white" : ""}`}>
          MINIMALIST
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex md:items-center md:gap-8">
          <Link
            href="/all-products"
            className={`text-sm tracking-wider transition-colors hover:text-gray-600 ${
              !isScrolled ? "text-white" : ""
            }`}
          >
            All Products
          </Link>
          <Link
            href="/collections"
            className={`text-sm tracking-wider transition-colors hover:text-gray-600 ${
              !isScrolled ? "text-white" : ""
            }`}
          >
            Collections
          </Link>
          <Link
            href="/collections/spring-summer-2024"
            className={`text-sm tracking-wider transition-colors hover:text-gray-600 ${
              !isScrolled ? "text-white" : ""
            }`}
          >
            Spring Summer 2024
          </Link>
          <Link
            href="/about"
            className={`text-sm tracking-wider transition-colors hover:text-gray-600 ${
              !isScrolled ? "text-white" : ""
            }`}
          >
            About
          </Link>
        </nav>

        {/* Icons */}
        <div className="flex items-center gap-4">
          <Link href="/search">
            <Button variant="ghost" size="icon" className={`hidden sm:inline-flex ${!isScrolled ? "text-white" : ""}`}>
              <Search className="h-5 w-5" />
              <span className="sr-only">Search</span>
            </Button>
          </Link>

          {/* Account Dropdown */}
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              className={`hidden sm:inline-flex ${!isScrolled ? "text-white" : ""}`}
              onClick={() => setIsAccountMenuOpen(!isAccountMenuOpen)}
            >
              <User className="h-5 w-5" />
              <span className="sr-only">Account</span>
            </Button>

            {isAccountMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 rounded-md border border-gray-200 bg-white py-1 shadow-lg">
                <Link
                  href="/account"
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  onClick={() => setIsAccountMenuOpen(false)}
                >
                  My Account
                </Link>
                <Link
                  href="/account/orders"
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  onClick={() => setIsAccountMenuOpen(false)}
                >
                  My Orders
                </Link>
                <Link
                  href="/login"
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  onClick={() => setIsAccountMenuOpen(false)}
                >
                  Sign In
                </Link>
                <Link
                  href="/register"
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  onClick={() => setIsAccountMenuOpen(false)}
                >
                  Create Account
                </Link>
              </div>
            )}
          </div>

          <Link href="/cart">
            <Button variant="ghost" size="icon" className={!isScrolled ? "text-white" : ""}>
              <ShoppingBag className="h-5 w-5" />
              <span className="sr-only">Cart</span>
            </Button>
          </Link>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 bg-white">
          <div className="container mx-auto px-4">
            <div className="flex h-16 items-center justify-between">
              <Link href="/" className="font-serif text-xl tracking-wider">
                MINIMALIST
              </Link>
              <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(false)}>
                <X className="h-6 w-6" />
                <span className="sr-only">Close menu</span>
              </Button>
            </div>
            <nav className="flex flex-col gap-6 py-8">
              <Link href="/all-products" className="text-lg tracking-wider" onClick={() => setIsMenuOpen(false)}>
                All Products
              </Link>
              <Link href="/collections" className="text-lg tracking-wider" onClick={() => setIsMenuOpen(false)}>
                Collections
              </Link>
              <Link
                href="/collections/spring-summer-2024"
                className="text-lg tracking-wider"
                onClick={() => setIsMenuOpen(false)}
              >
                Spring Summer 2024
              </Link>
              <Link href="/about" className="text-lg tracking-wider" onClick={() => setIsMenuOpen(false)}>
                About
              </Link>
              <div className="mt-4 flex flex-col gap-4">
                <Link
                  href="/account"
                  className="flex items-center gap-2 text-lg tracking-wider"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <User className="h-5 w-5" />
                  Account
                </Link>
                <Link
                  href="/login"
                  className="flex items-center gap-2 text-lg tracking-wider"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Sign In
                </Link>
                <Link
                  href="/register"
                  className="flex items-center gap-2 text-lg tracking-wider"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Create Account
                </Link>
                <Link
                  href="/search"
                  className="flex items-center gap-2 text-lg tracking-wider"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Search className="h-5 w-5" />
                  Search
                </Link>
                <Link
                  href="/cart"
                  className="flex items-center gap-2 text-lg tracking-wider"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <ShoppingBag className="h-5 w-5" />
                  Cart
                </Link>
              </div>
            </nav>
          </div>
        </div>
      )}
    </header>
  )
}
